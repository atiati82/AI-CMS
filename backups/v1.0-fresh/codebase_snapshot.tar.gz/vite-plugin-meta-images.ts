// Simple vite plugin to handle meta images
export function metaImagesPlugin() {
    return {
        name: 'meta-images',
        configureServer() {
            // Placeholder plugin - can be expanded later if needed
        }
    };
}
