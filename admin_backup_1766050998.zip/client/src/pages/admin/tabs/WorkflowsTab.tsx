
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter
} from "@/components/ui/dialog";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from "@/components/ui/select";
import {
    Play, Pause, RotateCcw, CheckCircle2, XCircle, Clock,
    AlertCircle, Activity, ArrowRight, Layers, FileText, Search,
    Loader2, MoreVertical, Terminal, ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { WorkflowExecution, WorkflowTemplate, WorkflowStepStatus } from './types';

export default function WorkflowsTab() {
    const { toast } = useToast();
    const queryClient = useQueryClient();
    const [selectedWorkflowId, setSelectedWorkflowId] = useState<string | null>(null);
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState<string>('');
    const [contextInput, setContextInput] = useState<string>('{}');

    // Fetch Workflows
    const { data: workflowsData, isLoading } = useQuery<{ ok: boolean; workflows: WorkflowExecution[] }>({
        queryKey: ['/api/ai/workflows'],
        queryFn: async () => {
            const res = await apiRequest('GET', '/api/ai/workflows');
            return res.json();
        },
        refetchInterval: 3000 // Poll every 3s for live updates
    });

    // Fetch Templates
    const { data: templatesData } = useQuery<{ ok: boolean; templates: WorkflowTemplate[] }>({
        queryKey: ['/api/ai/workflows/templates'],
        queryFn: async () => {
            const res = await apiRequest('GET', '/api/ai/workflows/templates');
            return res.json();
        },
    });

    // Mutations
    const createMutation = useMutation({
        mutationFn: async (data: { template: string; context: any }) => {
            const res = await apiRequest('POST', '/api/ai/workflows/create', data);
            return res.json();
        },
        onSuccess: (data) => {
            queryClient.invalidateQueries({ queryKey: ['/api/ai/workflows'] });
            setIsCreateModalOpen(false);
            setSelectedTemplate('');
            setContextInput('{}');

            // Auto-run the created workflow
            runMutation.mutate(data.workflowId);
            toast({ title: "Workflow Created", description: "Starting execution..." });
        }
    });

    const runMutation = useMutation({
        mutationFn: async (id: string) => {
            const res = await apiRequest('POST', `/api/ai/workflows/${id}/run`);
            return res.json();
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['/api/ai/workflows'] });
        }
    });

    const pauseMutation = useMutation({
        mutationFn: async (id: string) => {
            const res = await apiRequest('POST', `/api/ai/workflows/${id}/pause`);
            return res.json();
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['/api/ai/workflows'] });
            toast({ title: "Workflow Paused" });
        }
    });

    const workflows = workflowsData?.workflows || [];
    const selectedWorkflow = workflows.find(w => w.id === selectedWorkflowId) || workflows[0];

    // Stats
    const stats = {
        running: workflows.filter(w => w.status === 'running').length,
        completed: workflows.filter(w => w.status === 'completed').length,
        failed: workflows.filter(w => w.status === 'failed').length,
    };

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'running': return <Activity className="w-4 h-4 text-blue-500 animate-pulse" />;
            case 'completed': return <CheckCircle2 className="w-4 h-4 text-green-500" />;
            case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
            case 'paused': return <Pause className="w-4 h-4 text-yellow-500" />;
            default: return <Clock className="w-4 h-4 text-muted-foreground" />;
        }
    };

    const getStepStatusColor = (status: WorkflowStepStatus) => {
        switch (status) {
            case 'completed': return 'bg-green-500/10 text-green-500 border-green-500/20';
            case 'running': return 'bg-blue-500/10 text-blue-500 border-blue-500/20 animate-pulse';
            case 'failed': return 'bg-red-500/10 text-red-500 border-red-500/20';
            case 'skipped': return 'bg-muted text-muted-foreground';
            default: return 'bg-muted/30 text-muted-foreground';
        }
    };

    return (
        <div className="h-[calc(100vh-100px)] flex flex-col gap-4">
            {/* Header Stats */}
            <div className="grid grid-cols-4 gap-4">
                <Card className="bg-primary/5 border-primary/20">
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs text-muted-foreground font-medium uppercase">Active Workflows</p>
                            <h3 className="text-2xl font-bold text-primary">{stats.running}</h3>
                        </div>
                        <Activity className="w-8 h-8 text-primary/50" />
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs text-muted-foreground font-medium uppercase">Completed</p>
                            <h3 className="text-2xl font-bold text-green-500">{stats.completed}</h3>
                        </div>
                        <CheckCircle2 className="w-8 h-8 text-green-500/20" />
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4 flex items-center justify-between">
                        <div>
                            <p className="text-xs text-muted-foreground font-medium uppercase">Failed</p>
                            <h3 className="text-2xl font-bold text-red-500">{stats.failed}</h3>
                        </div>
                        <AlertCircle className="w-8 h-8 text-red-500/20" />
                    </CardContent>
                </Card>
                <div className="flex items-center justify-end">
                    <Button onClick={() => setIsCreateModalOpen(true)} className="w-full h-full text-lg shadow-lg bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-600/90">
                        <Play className="w-5 h-5 mr-2" /> Run New Workflow
                    </Button>
                </div>
            </div>

            <div className="flex gap-6 h-full min-h-0">
                {/* Left Panel: List */}
                <div className="w-1/3 flex flex-col gap-4">
                    <Card className="flex-1 flex flex-col min-h-0 border-primary/10 shadow-sm">
                        <CardHeader className="py-3 px-4 border-b bg-muted/20">
                            <CardTitle className="text-sm font-medium">History</CardTitle>
                        </CardHeader>
                        <ScrollArea className="flex-1">
                            <div className="p-2 space-y-2">
                                {workflows.map(wf => (
                                    <div
                                        key={wf.id}
                                        onClick={() => setSelectedWorkflowId(wf.id)}
                                        className={cn(
                                            "group flex flex-col gap-2 p-3 rounded-lg border transition-all cursor-pointer hover:bg-muted/50",
                                            selectedWorkflow?.id === wf.id
                                                ? "bg-primary/5 border-primary/30 shadow-[0_0_10px_-5px_var(--primary)]"
                                                : "bg-card border-border/40"
                                        )}
                                    >
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-2">
                                                {getStatusIcon(wf.status)}
                                                <span className="font-semibold text-sm">{wf.name || 'Untitled Workflow'}</span>
                                            </div>
                                            <Badge variant="outline" className="text-[10px] h-5">{wf.status}</Badge>
                                        </div>

                                        <div className="space-y-1">
                                            <div className="flex justify-between text-xs text-muted-foreground">
                                                <span>Step {wf.currentStep + 1} of {wf.steps?.length || '?'}</span>
                                                <span>{new Date(wf.createdAt).toLocaleTimeString()}</span>
                                            </div>
                                            <Progress value={((wf.currentStep) / (wf.steps?.length || 1)) * 100} className="h-1" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </ScrollArea>
                    </Card>
                </div>

                {/* Right Panel: Detail */}
                <div className="w-2/3 flex flex-col gap-4">
                    {selectedWorkflow ? (
                        <Card className="flex-1 flex flex-col min-h-0 border-primary/10 shadow-md">
                            <CardHeader className="py-4 px-6 border-b bg-muted/10 flex flex-row items-center justify-between">
                                <div>
                                    <CardTitle className="flex items-center gap-2">
                                        {selectedWorkflow.name}
                                        <Badge variant={selectedWorkflow.status === 'running' ? 'default' : 'outline'}>
                                            {selectedWorkflow.status}
                                        </Badge>
                                    </CardTitle>
                                    <CardDescription className="font-mono text-xs mt-1 text-muted-foreground/70">
                                        ID: {selectedWorkflow.id} • Started {new Date(selectedWorkflow.createdAt).toLocaleString()}
                                    </CardDescription>
                                </div>
                                <div className="flex gap-2">
                                    {selectedWorkflow.status === 'running' && (
                                        <Button size="sm" variant="outline" onClick={() => pauseMutation.mutate(selectedWorkflow.id)}>
                                            <Pause className="w-4 h-4 mr-1" /> Pause
                                        </Button>
                                    )}
                                    {(selectedWorkflow.status === 'paused' || selectedWorkflow.status === 'failed') && (
                                        <Button size="sm" onClick={() => runMutation.mutate(selectedWorkflow.id)}>
                                            <Play className="w-4 h-4 mr-1" /> Resume
                                        </Button>
                                    )}
                                </div>
                            </CardHeader>

                            <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                                <div className="grid grid-cols-2 h-full">
                                    {/* Steps Visualization */}
                                    <div className="border-r bg-muted/5 p-6 overflow-y-auto">
                                        <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-4">Workflow Steps</h4>
                                        <div className="relative space-y-6">
                                            {/* Connector Line */}
                                            <div className="absolute left-3 top-3 bottom-3 w-0.5 bg-border/50 -z-10" />

                                            {selectedWorkflow.steps?.map((step, idx) => (
                                                <div key={idx} className="relative pl-8">
                                                    {/* Dot */}
                                                    <div className={cn(
                                                        "absolute left-[5px] top-1.5 w-3 h-3 rounded-full border-2 bg-background z-10 transition-colors",
                                                        step.status === 'completed' ? "border-green-500 bg-green-500" :
                                                            step.status === 'running' ? "border-blue-500 bg-blue-500 animate-pulse" :
                                                                step.status === 'failed' ? "border-red-500 bg-red-500" :
                                                                    "border-muted-foreground/30"
                                                    )} />

                                                    <div className={cn(
                                                        "p-3 rounded-lg border text-sm transition-all",
                                                        getStepStatusColor(step.status)
                                                    )}>
                                                        <div className="flex justify-between items-start mb-1">
                                                            <span className="font-medium">{step.name}</span>
                                                            {step.status === 'running' && <Loader2 className="w-3 h-3 animate-spin" />}
                                                        </div>
                                                        <p className="text-xs opacity-70 mb-2">Agent: {step.agent || 'System'}</p>

                                                        {step.error && (
                                                            <div className="text-xs bg-red-500/10 p-2 rounded text-red-600 font-mono mt-2 break-all">
                                                                Error: {step.error}
                                                            </div>
                                                        )}

                                                        {step.result && (
                                                            <div className="mt-2 pt-2 border-t border-black/5 text-xs font-mono opacity-80">
                                                                <div className="flex items-center gap-1 text-[10px] uppercase tracking-wider mb-1">
                                                                    <Terminal className="w-3 h-3" /> Output
                                                                </div>
                                                                <div className="line-clamp-3">
                                                                    {typeof step.result === 'object' ? JSON.stringify(step.result).substring(0, 100) : String(step.result)}
                                                                </div>
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    {/* Logs / Console */}
                                    <div className="flex flex-col bg-[#0F1117] text-gray-300 font-mono text-xs">
                                        <div className="px-4 py-2 border-b border-white/10 bg-white/5 flex items-center gap-2">
                                            <Terminal className="w-3 h-3" />
                                            <span>Execution Logs</span>
                                        </div>
                                        <ScrollArea className="flex-1 p-4">
                                            <div className="space-y-1.5 opacity-90">
                                                <div className="text-gray-500">[{new Date(selectedWorkflow.createdAt).toLocaleTimeString()}] Workflow started</div>
                                                {selectedWorkflow.steps?.filter(s => s.status !== 'pending').map((step, idx) => (
                                                    <React.Fragment key={idx}>
                                                        <div className="text-blue-400">[{step.startedAt ? new Date(step.startedAt).toLocaleTimeString() : '...'}] Starting step: {step.name}</div>
                                                        {step.status === 'completed' && (
                                                            <div className="text-green-400">
                                                                [{step.completedAt ? new Date(step.completedAt).toLocaleTimeString() : '...'}] Completed: {step.name}
                                                                <br />
                                                                <span className="text-gray-500 pl-4">Output: {JSON.stringify(step.result)?.substring(0, 50)}...</span>
                                                            </div>
                                                        )}
                                                        {step.status === 'failed' && (
                                                            <div className="text-red-400">[{new Date().toLocaleTimeString()}] Error in {step.name}: {step.error}</div>
                                                        )}
                                                    </React.Fragment>
                                                ))}
                                                {selectedWorkflow.status === 'completed' && (
                                                    <div className="text-green-500 font-bold mt-2">[{new Date().toLocaleTimeString()}] Workflow execution completed successfully.</div>
                                                )}
                                            </div>
                                        </ScrollArea>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    ) : (
                        <div className="flex-1 flex items-center justify-center border-2 border-dashed rounded-lg text-muted-foreground">
                            <div className="text-center">
                                <Layers className="w-12 h-12 mx-auto mb-2 opacity-20" />
                                <p>Select a workflow to view details</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Create Modal */}
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Start New Workflow</DialogTitle>
                        <DialogDescription>
                            Select a template to spawn a specific agentic workflow.
                        </DialogDescription>
                    </DialogHeader>

                    <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                            <label className="text-sm font-medium">Template</label>
                            <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                                <SelectTrigger>
                                    <SelectValue placeholder="Select template..." />
                                </SelectTrigger>
                                <SelectContent>
                                    {templatesData?.templates.map(t => (
                                        <SelectItem key={t.id} value={t.id}>
                                            <div className="flex flex-col items-start">
                                                <span className="font-medium">{t.name}</span>
                                                <span className="text-xs text-muted-foreground">{t.description}</span>
                                            </div>
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        <div className="grid gap-2">
                            <label className="text-sm font-medium">Context (JSON)</label>
                            <textarea
                                className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 font-mono"
                                value={contextInput}
                                onChange={(e) => setContextInput(e.target.value)}
                                placeholder='{ "topic": "ionic water" }'
                            />
                            <p className="text-[10px] text-muted-foreground">
                                Required params: {templatesData?.templates.find(t => t.id === selectedTemplate)?.requiredParams.join(', ') || 'None'}
                            </p>
                        </div>
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>Cancel</Button>
                        <Button
                            onClick={() => {
                                try {
                                    const context = JSON.parse(contextInput);
                                    createMutation.mutate({ template: selectedTemplate, context });
                                } catch (e) {
                                    toast({ title: "Invalid JSON", variant: "destructive" });
                                }
                            }}
                            disabled={!selectedTemplate || createMutation.isPending}
                        >
                            {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                            Start Workflow
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
